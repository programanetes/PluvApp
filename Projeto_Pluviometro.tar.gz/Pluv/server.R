library(shiny)
library(shinydashboard)
source("user.r")
source("admin.R")

my_username <- c("test","admin")
my_password <- c("test","123")
get_role=function(user){
  
  if(user=="test") {
    
    return("TEST")
  }else{
    
    return("ADMIN")
  }
}

get_ui=function(role){
  itog=list()
  if(role=="TEST"){
   
    itog$main=test_main

    return(itog)
  }else{
    itog$main=admin_main
    return(itog)
  }
}


shinyServer(function(input, output,session) {
  
  #############app############
  output$image <- renderImage({
      
     return(list(
        src = "fstpage.png",
        filetype = "image/png",
        width = "100%",
        height = "150%"
      ))
      
    },deleteFile=FALSE)

  #####################################################################################################################
  #Colocar Mapa aqui
  src = "fstpage.png"
  output$mapOut <- renderUI({
    pluv_names <-c(
      "PLUVIÔMETRO SEMIAUTOMÁTICO - EM Pres. Jânio da Silva Quadros | Vila Nunes",
      "PLUVIÔMETRO SEMIAUTOMÁTICO - EM Governador Mário Covas | Bairro da Cruz",
      "PLUVIÔMETRO SEMIAUTOMÁTICO - EM Anna Pereira de Lacerda | Pq. das Rodovias",
      "PLUVIÔMETRO SEMIAUTOMÁTICO - EM Climério Galvão César | Olaria",
      "PLUVIÔMETRO SEMIAUTOMÁTICO - EM Profª Lúcia Maria Vilar Barbosa| Cecap Baixa",
      "PLUVIÔMETRO SEMIAUTOMÁTICO - EM Pe. João Renaudin de Ranville| Ponte Nova"
      
      
      
)
    lat =c(-22.7338724,-22.7383693,-22.7358056,-22.7470212,
           -22.7338724,-22.7536613)
    
    long =c(-45.1201112,-45.1069752,-45.0935447,-45.1132752,
            -45.1201112,-45.1253214)
    
    sp <- as.data.frame(cbind(long=long,lat=lat))
    rownames(sp)<-pluv_names
    coordinates(sp) <- ~long+lat
    proj4string(sp) <- CRS("+proj=longlat +datum=WGS84")
    sp <- SpatialPointsDataFrame( sp , data = data.frame( ID = row.names( sp ) ) )
    plotGoogleMaps(sp , filename='myMap1.html',legend = FALSE,openMap  = FALSE)
    tags$iframe(
      srcdoc = paste(readLines('myMap1.html'), collapse = '\n'),
      width = "100%",
      height = "600px"
    )
    
  })
  
  #####################################################################################################################
  
  
  #Colocando as opções certinhas
  output$options1 <- renderUI({
    selectInput("options1", NULL, c("Diária","Mensal","Anual"), selected = NULL)
  })
  output$options2 <- renderUI({
    selectInput("options2", "Início", meses, selected = NULL)
  })
  output$options3 <- renderUI({
    selectInput("options3", NULL, anos, selected = NULL)
  })
  output$options4 <- renderUI({
    selectInput("options4", "Fim", meses, selected = NULL)
  })
  output$options5 <- renderUI({
    selectInput("options5", NULL, anos, selected = NULL)
  })
  output$options6 <- renderUI({
    selectInput("options6",NULL, local, selected = NULL)
  })
  
  #Colocando o painel para quando selecionar o caso dos dados
  output$painel <- renderUI({
    if(input$go){
      tabBox(
        title = "Dados",
        id = "ttabs",
        width = 12,
        height = "420px",
        tabPanel("Gráfico", htmlOutput("plots")),
        tabPanel("Tabelas",
                 fluidRow(
                   column(12,
                          tableOutput("tables")),
                   column(12,
                          box(
                            title = "Boxsplot",
                            status = "primary",
                            solidHeader = TRUE,
                            height = 420,
                            plotOutput("box", height=350)))
                 )
        ),
        tabPanel("Dados", dataTableOutput("data")),
        tabPanel("Descrição",
                 fluidRow(
                   column(6,
                          uiOutput("bot1"),
                          uiOutput("bot2"),
                          uiOutput("bot3"),
                          uiOutput("bot4")
                   ),
                   column(6,
                          uiOutput("bot5"),
                          uiOutput("bot6"),
                          uiOutput("bot7"),
                          uiOutput("bot8")
                   )
                 )
        )
      )
    }
  })
  
  observeEvent(input$go,{
    #Selecionando dados a partir de Período e Local
    rotulos <- data.frame(tabelaOrig$mes, tabelaOrig$ano)
    rotulos <- unique(rotulos)
    rownames(rotulos) <- 1:nrow(rotulos)
    
    #Obtendo inicio e fim
    aux <- rotulos[is.element(rotulos$tabelaOrig.mes, input$options2),]
    index1 <- rownames(aux[is.element(aux$tabelaOrig.ano, input$options3), ])
    
    aux <- rotulos[is.element(rotulos$tabelaOrig.mes, input$options4),]
    index2 <- rownames(aux[is.element(aux$tabelaOrig.ano, input$options5), ])
    
    #Selecionando informações sobre os lugares
    tabela <- tabelaOrig
    
    #Selecionando informações para visualização de dados
    x <- c()
    y <- c()
    tabelaDados <- data.frame()
    dadosTotais <- c()
    
    #No caso de possuirmos a seleção em Anual #########################################################
    if(input$options1 == "Anual"){
      #Contabilidade dos casos
      total <- 0
      totalna <- 0
      
      for(i in input$options3:input$options5){
        x <- append(x,i)
        tabelaDados <- rbind(tabelaDados, tabela[tabela$ano==i,])
        tabelaAux <- tabela[tabela$ano==i,7]
        total <- total + length(tabelaAux)
        totalna <- totalna + length(tabelaAux["NA"])
        dadosTotais <- append(dadosTotais,tabelaAux)
        y <- append(y,mean(tabelaAux,na.rm=TRUE))
      }
      
      #Gráfico
      output$plots <- renderGvis({
        auxGraph <- data.frame(x,y)
        gvisColumnChart(auxGraph)
      })
      
      #Dados selecionados
      colnames(tabelaDados) <- c("Dia", "Hora","1h", "4h", "7h","19h", "24h","48h","72h","96h","Local","Mês","Ano")
      output$data <- renderDataTable(tabelaDados, option=list(pageLength=4))
      
      #Tabela Resumo e Boxplot
      media <- mean(y)
      maximo <- max(y)
      minimo <- min(y)
      mediana <- median(y, na.rm=TRUE)
      variancia <- var(y, na.rm=TRUE)
      desvio <- sd(y, na.rm=TRUE)
      matrix <- matrix(c(media,mediana,variancia,desvio,minimo,maximo,total,totalna), nrow=1)
      colnames(matrix) <- c("Média", "Mediana", "Variância", "Desvio Padrão", "Mínimo", "Máximo", "Total de medições", "Medições Inválidas")
      
      output$tables <- renderTable({
        matrix
      })
      
      output$box <- renderPlot({
        boxplot(dadosTotais, na.rm=TRUE)
      })
    }
    
    
    #No caso de possuirmos a seleção em Mensal #########################################################
    else if(input$options1 == "Mensal"){
      #Contabilidade dos Casos
      total <- 0
      totalna <- 0
      
      for(i in index1:index2){
        x <- append(x,paste(rotulos[i,1], rotulos[i,2]))
        tabelaAux1 <- tabela[tabela$mes==rotulos[i,1],]
        tabelaDados <- rbind(tabelaDados, tabelaAux1[tabelaAux1$ano==rotulos[i,2],])
        tabelaAux2 <- tabelaAux1[tabelaAux1$ano==rotulos[i,2],7]
        total <- total + length(tabelaAux2)
        totalna <- total + length(tabelaAux2["NA"])
        dadosTotais <- append(dadosTotais,tabelaAux2)
        w <- sapply(tabelaAux2, function(x)all(is.na(x)))
        if(!any(w)){
          y <- append(y,0)
        }
        else{
          y <- append(y,mean(tabelaAux2,na.rm=TRUE)) 
        }
      }
      
      #Gráfico
      output$plots <- renderGvis({
        auxGraph <- data.frame(x,y)
        gvisColumnChart(auxGraph)
      })
      
      #Dados Selecionados
      colnames(tabelaDados) <- c("Dia", "Hora","1h", "4h", "7h","19h", "24h","48h","72h","96h","Local","Mês","Ano")
      output$data <- renderDataTable(tabelaDados, option=list(pageLength=4))
      
      #Tabela Resumo e Boxplot
      media <- mean(y)
      maximo <- max(y)
      minimo <- min(y)
      mediana <- median(y, na.rm=TRUE)
      variancia <- var(y, na.rm=TRUE)
      desvio <- sd(y, na.rm=TRUE)
      matrix <- matrix(c(media,mediana,variancia,desvio,minimo,maximo,total,totalna), nrow=1)
      colnames(matrix) <- c("Média", "Mediana", "Variância", "Desvio Padrão", "Mínimo", "Máximo", "Total de medições", "Medições Inválidas")
      
      output$tables <- renderTable({
        matrix
      })
      
      output$box <- renderPlot({
        boxplot(dadosTotais, na.rm=TRUE)
      })
      
    }
    
    #No caso de possuirmos a seleção em diária ########################################################
    else{
      #Contabilidade dos casos
      total <- 0
      totalna <- 0
      
      for(i in index1:index2){
        tabelaAux1 <- tabela[tabela$mes==rotulos[i,1],]
        tabelaAux2 <- tabelaAux1[tabelaAux1$ano==rotulos[i,2],]
        for(j in 1:31){
          if(j %in% tabelaAux2$dia){
            tabelaDados <- rbind(tabelaDados, tabelaAux2[tabelaAux2$dia==j,])
            x <- append(x, paste(j,rotulos[i,1],rotulos[i,2]))
            tabelaAux3 <- tabelaAux2[tabelaAux2$dia==j,7]
            total <- total + length(tabelaAux3)
            totalna <- totalna + length(tabelaAux3["NA"])
            dadosTotais <- append(dadosTotais,tabelaAux3)
            y <- append(y, mean(tabelaAux2[tabelaAux2$dia==j,7], na.rm=TRUE))
          }
        }
      }
      
      #Gráfico
      output$plots <- renderGvis({
        auxGraph <- data.frame(x,y)
        gvisColumnChart(auxGraph)
      })
      
      #Dados Selecionados
      colnames(tabelaDados) <- c("Dia", "Hora","1h", "4h", "7h","19h", "24h","48h","72h","96h","Local","Mês","Ano")
      output$data <- renderDataTable(tabelaDados, option=list(pageLength=4))
      
      #Tabela Resumo e Boxplot
      media <- mean(y)
      maximo <- max(y)
      minimo <- min(y)
      mediana <- median(y, na.rm=TRUE)
      variancia <- var(y, na.rm=TRUE)
      desvio <- sd(y, na.rm=TRUE)
      matrix <- matrix(c(media,mediana,variancia,desvio,minimo,maximo,total,totalna), nrow=1)
      colnames(matrix) <- c("Média", "Mediana", "Variância", "Desvio Padrão", "Mínimo", "Máximo", "Total de medições", "Medições Inválidas")
      
      output$tables <- renderTable({
        matrix
      })
      
      output$box <- renderPlot({
        boxplot(dadosTotais, na.rm=TRUE)}
      )
    }
    
    #Inserindo descrição com as medidas-resumo
    output$bot1 <- renderUI({
      valueBox("Máximo",
               "Maior valor de todas as observações",
               icon=icon("hand-up", lib="glyphicon"), width=10,color = "navy")
      
    })
    output$bot2 <- renderUI({
      valueBox("Média",
               "É a soma das observações dividida pelo total de observações",
               icon=icon("stats", lib="glyphicon"), width=10,color = "purple")
      
    })
    output$bot3 <- renderUI({
      valueBox("Variância",
               "é uma medida de dispersão que indica quão longe em geral os seus valores se encontram da média.",
               icon=icon("calculator"), width=10,color = "light-blue")
      
      
    })
    output$bot4 <- renderUI({
      
      valueBox("BoxPlot",
               "É um gráfico utilizado para observar a distribuição empírica do dados. O boxplot é formado pelo primeiro e terceiro quartil e pela mediana.",
               icon=icon("line-chart"), width=10,color = "aqua")
    })
    output$bot5 <- renderUI({
      valueBox("Mínimo", 
               "Menor valor de todas as observações",
               icon=icon("hand-down", lib="glyphicon"), width=10,color = "navy")
    })
    output$bot6 <- renderUI({
      valueBox("Mediana",
               "É o valor da variável que ocupa a posição central do conjunto de dados",
               icon=icon("stats", lib="glyphicon"), width=10,color="purple")
      
    })
    output$bot7 <- renderUI({
      valueBox("Desvio Padrão",
               "Indica em média qual será o erro cometido ao se tentar substituir cada observação pela média do conjunto de dados.",
               icon=icon("calculator"), width=10,color = "light-blue")
      
    })
    output$bot8 <- renderUI({
      valueBox("Quartil",
               "São valores observador a partir do conjunto de dados ordenado em ordem crescente, que dividem o conjunto quatro partes iguais.",
               icon=icon("line-chart"), width=10,color = "aqua")
      
    })
  })
  output$msg <- renderUI({
    data1 <- data.frame(dia = input$dia,
                        hora = input$h_id,
                        X1h = input$`1_id`,
                        X4h = input$`4_id`,
                        X7h = NA,
                        X19h = NA,
                        X24h = input$`24_id`,
                        X48h = input$`48_id`,
                        X72h = input$`72_id`,
                        X96h = input$`96_id`,
                        lugar = input$pluv_id,
                        mes = input$mes,
                        ano = input$ano,
                        stringsAsFactors = FALSE
                        
    )
    if(input$confere){
      k<-data1
      tabPanel("Check",
               data1[1,])
    }
    
  })
  output$gravar<- renderUI({
    row1 <- data.frame(dia = input$dia,
                       hora = input$h_id,
                       X1h = input$`1_id`,
                       X4h = input$`4_id`,
                       X7h = NA,
                       X19h = NA,
                       X24h = input$`24_id`,
                       X48h = input$`48_id`,
                       X72h =  input$`72_id`,
                       X96h = input$`96_id`,
                       lugar = input$pluv_id,
                       mes = input$mes,
                       ano = input$ano,
                       stringsAsFactors = FALSE
                       
    )
    if(input$gravar){
      file <- read.csv("pluvia.csv",header=TRUE)
      size_ini <- dim(file)[1]
      dataaux<-rbind(file,row1)
      
      write.csv(dataaux, file = "pluvia.csv",row.names=FALSE, fileEncoding = "UTF-8")
      size_fim <- dim(read.csv2("pluvia.csv",header=TRUE))[1]
      if(size_ini < size_fim){
        #       updateTextInput(session, "dia", value = " ")     
        #      updateTextInput(session, "mes", value = " ") 
        #     updateTextInput(session, "ano", value = " ")     
        #    updateTextInput(session, "1_id", value = " ") 
        #   updateTextInput(session, "4_id", value = " ")     
        #  updateTextInput(session, "24_id", value = " ") 
        # updateTextInput(session, "48_id", value = " ")     
        #updateTextInput(session, "72_id", value = " ") 
        # updateTextInput(session, "96_id", value = " ") 
        valueBox("Gravados",
                 "Valores gravados",
                 icon=icon("warning", lib="glyphicon"), width=5,color="green")
        
        
      }
      
      
      
    }
  })
      
  
  #Lendo data-frame ###################################################################################
  tabelaOrig = read.csv("pluvi.csv")
  meses = c("Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro")
  anos = unique(tabelaOrig$ano)
  local = unique(tabelaOrig$lugar)

  #############Fim app############
  USER <- reactiveValues(Logged = FALSE,role=NULL)
  
  ui1 <- function(){
    tagList(
      div(id = "login",
          wellPanel(textInput("userName", "Username"),
                    passwordInput("passwd", "Password"),
                    br(),actionButton("Login", "Log in")))
      #,tags$style(type="text/css", "#login {font-size:10px;   text-align: left;position:absolute
                 # ;top: 40%;left: 50%;margin-top: -10px;margin-left: -150px;}")
    )}
  
  
  observe({ 
    if (USER$Logged == FALSE) {
      if (!is.null(input$Login)) {
        if (input$Login > 0) {
          Username <- isolate(input$userName)
          Password <- isolate(input$passwd)
          Id.username <- which(my_username == Username)
          Id.password <- which(my_password == Password)
          if (length(Id.username) > 0 & length(Id.password) > 0) {
            if (Id.username == Id.password) {
              USER$Logged <- TRUE
              USER$role=get_role(Username)
              
            }
          } 
        }
      }
    }
  })
  observe({
    if (USER$Logged == FALSE) {
      
      output$page <- renderUI({
        box(
          div(class="outer",do.call(bootstrapPage,c("",ui1()))))
      })
    }
    if (USER$Logged == TRUE)    {
      itog=get_ui(USER$role)
      output$page <- renderUI({
        itog$main
      })
    }
  })
})