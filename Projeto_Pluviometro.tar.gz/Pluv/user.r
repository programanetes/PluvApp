
test_main=list(
  tabItem(
    
    tabName = "entrada1",
    box(
      splitLayout( textInput("dia","Dia",""),
                   textInput("mes","Mês",""),
                   textInput("ano","Ano","")
                   
      ),
      selectInput("pluv_id", "Pluviometros",
                  list("EM Pres. Jânio da Silva Quadros | Vila Nunes",
                       "EM Anna Pereira de Lacerda | Pq. das Rodovias",
                       "EM Governador Mário Covas | Bairro da Cruz",
                       "EM Climério Galvão César | Olaria",
                       "EM Profª Lúcia Maria Vilar Barbosa | Cecap Baixa",
                       "EM Pe. João Renaudin de Ranville | Ponte Nova",
                       "SECRETARIA DE SEGURANÇA MUNICIPAL - Praça Marechal Mallet | Centro",
                       "CIA POLÍCIA MILITAR | Vila Hepacaré",
                       "EM Professor Ruy Brasil Pereira | Novo Horizonte"
                  )
      ),
      textInput("h_id","Horário da coleta",""),
      splitLayout(
        cellWidths = 65,
        textInput("1_id","1 Hora",""),
        textInput("4_id","4 Horas",""),
        # textInput("7_id","7 Horas",""),
        # textInput("19_id","19 Horas",""),
        textInput("24_id","24 Horas",""),
        textInput("48_id","48 Horas",""),
        textInput("72_id","72 Horas",""),
        textInput("96_id","96 Horas","")
      ),
      splitLayout(actionButton("confere", "Conferir", width = "100px"),
                  tags$style(type='text/css', "#confere { padding-bottom: 4px; }"),
                  actionButton("gravar", "Gravar", width = "100px"),
                  tags$style(type='text/css', "#gravar { padding-bottom: 4px; }"))
      
    ),
    
    box(
      uiOutput("msg")
    ),
    uiOutput("gravar")        
    
    
  )
 
  )
