library(shinyTime)
library(shinyBS)
library(googleVis)
library(XML)
library(plotGoogleMaps)
library(sp)
library(rgdal)
library(shiny)
library(RColorBrewer)
library(plyr)
library(shinydashboard)


shinyUI( 
  dashboardPage(
    dashboardHeader(title = "UNIFESP/CEMADEN", titleWidth = 300),
    dashboardSidebar(width=300,#Adicionando barra de rolagem
                       tags$head(
                         tags$style(HTML("
                                         .sidebar { height: 90vh; overflow-y: auto; }
                                         " )
                                    )
                         ),
                     sidebarMenu(
                       id = "menu1",
                       menuItem("Projeto", icon = icon("group"), tabName = "descricao"),
                       menuItem("Pluviômetros", icon = icon("map"), tabName = "mapa"),
                       menuItem("Informações Atuais", icon = icon("info"), tabName = "info"),
                       menuItem("Análise de Precipitações", icon = icon("bar-chart"), tabName = "estat"),
                       #ELaborando o caso de o usuário selecionar estatísticas
                       conditionalPanel(
                         condition = "input.menu1 == 'estat'",
                         below = "entrada",
                         fluidRow(
                           column(width=12,
                                  box(width = NULL, title = "Modalidade",
                                      "Modalidade de Análise: Anual/Mensal/Diário",
                                      background = "navy",
                                      uiOutput("options1")
                                  ),
                                  
                                  box(width = NULL, title = "Período",
                                      background = "navy",
                                      solidHeader = TRUE,
                                      "Período de Análise. Escolha o desejado",
                                      fluidRow(
                                        column(6,
                                               uiOutput("options2"),
                                               uiOutput("options3")),
                                        column(6,
                                               uiOutput("options4"),
                                               uiOutput("options5"))
                                      )
                                  ),
                                  box(width = NULL, title = "Local",
                                      background = "navy",
                                      solidHeader = TRUE,
                                      "Pluviômetros inclusos na análise",
                                      uiOutput("options6")
                                  ),
                                  box(width = NULL, background = "blue", solidHeader = TRUE,
                                      actionButton("go", "Analisar", width = "200px")   
                                  )
                           )
                         )
                       ),
                       menuItem("Entrada de Dados", icon = icon("archive"), tabName = "entrada"),
                       menuItem("Contato", icon = icon("envelope"), tabName = "contato")
                     )#endMenu
                     ),#endSideBar
  
    dashboardBody(
      tabItems(
        tabItem(
          tabName = "descricao",
          imageOutput("image")
        ),
        
        tabItem(
          tabName = "estat",
          uiOutput("painel")
        ),
        
        tabItem(
          tabName = "mapa",
          wellPanel(
            htmlOutput("mapOut")
          )
        ),
        
        tabItem(
          tabName = "entrada",
          uiOutput("page")
        )
        
      )#endItems
    )
   
  )
)
